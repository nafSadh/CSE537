######################################
# Run the following commands in order:

# Generate a puzzle. Write the puzzle to puzzle.txt
python sudokuGenerator.py

# Read puzzle.txt and solve it. Write the solution to solution.txt
python sudokuSolver.py

# Read solution.txt and check it
python sudokuChecker.py

